import java.util.Arrays;

class Main {

	public static void main(String[] args) {
		int[] l = { 9, 5, 4, 3, 3 };

		int sum = 0;
		boolean done = false;
		Arrays.sort(l);

		for (int i = 0; i < l.length; i++) {
			sum += l[i];
		}
		int max = 0;
		String maxS = "";

		if (sum % 3 == 0) {

			Arrays.sort(l);
			for (int i = l.length - 1; i >= 0; i--) {
				max += (l[i] * Math.pow(10, i));
			}

		}

		if (sum % 3 != 0) {
			int d = sum % 3;
			

			for (int i = 0; i < l.length; i++) {
				if ((l[i] % 3 == d) && !done) {
					done = true;
					for (int j = l.length - 1; j >= 0; j--) {
						if (i != j) {
							maxS += String.valueOf(l[j]);
						}
					}
					max = Integer.valueOf(maxS);
				}
			}

			for (int i = 0; i < l.length; i++) {
				for (int j = i + 1; j < l.length; j++) {
					int e = l[i] + l[j];
					if ((e % 3 == d) && !done) {
						done = true;
						for (int k = l.length - 1; k >= 0; k--) {
							if ((k != i) && (k != j)) {
								maxS += String.valueOf(l[k]);
							}
						}
						if (!maxS.equals(""))
						{
							max = Integer.valueOf(maxS);
						}
						break;
					}
				}
			}
		}

		System.out.println(max);
	}
}